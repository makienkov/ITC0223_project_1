"""
!/usr/bin/env python3
coding=utf-8
----------------------------------------------------------------
Global scope
----------------------------------------------------------------
"""
import string
import time
import sys
import logging
import json
import re
import argparse
from datetime import datetime
from datetime import timedelta
import grequests
import requests
from bs4 import BeautifulSoup
import pytz
import mysql.connector
from prettytable import PrettyTable


FILE_NAME = ".".join(__file__.split(".")[:-1])

logging.basicConfig(
    filename=FILE_NAME + ".log",
    level=logging.DEBUG,
    format="%(levelname)s - %(asctime)s - %(message)s",
)


def url_request(url: str) -> str:
    """A function that:
    "requests" the HTML page from the given string  - URL,
    and will return the HTML page
    """
    logging.info("url_request() was called with:\n %s", url)

    time.sleep(0.2)

    header = {
        "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:66.0) \
            Gecko/20100101 Firefox/66.0",
        "Accept-Encoding": "*",
        "Connection": "keep-alive",
    }

    try:
        response = requests.get(url, headers=header, timeout=9.9)
        response.raise_for_status()
        logging.info("connected to server successfully")
    except requests.exceptions.HTTPError as error:
        print(f"An error occurred: {error}")
        logging.error("server unreachable !%s", error)
        logging.critical("Exiting program...")
        sys.exit()

    if response.status_code != 200:
        print(f"Request failed with status code: {response.status_code}")
        logging.error("Request failed with status code: %s", response.status_code)
        print("closing program")
        logging.error("closing program")
        sys.exit()
    else:
        logging.info("Request fetched successfully, code=200")
        logging.info("url_request() was ended")
        return response.text


def url_to_soup(url: str) -> BeautifulSoup:
    """A function that:
    "requests" the HTML page from the given string  - URL,
    and parse it with BeautifulSoup will return the corresponding
    object.
    """
    logging.info("url_to_soup() was called with:\n %s", url)

    html = url_request(url)

    soup = BeautifulSoup(html, "html.parser")

    logging.info("url_to_soup() ended")

    return soup


def extract_links_and_titles():
    """A function that:
    extracts article's links (full and short) from news main page(s).
    Outputs a dict of {title1: [href, title_id..],...}

    :param num_pages: number of pages to scrap
    :return: a dict with data per title
    """
    logging.info("extract_links_and_titles() was called with:\n ")

    output_dict = {}

    url = "https://seekingalpha.com/market-news?page=1"

    link_soup = url_to_soup(url)
    #print(link_soup.prettify())

    select_object = link_soup.select("article div div footer a")
    print("$$$$$$select_object$$$$$$$$$$")
    print(select_object[0])
    print("text:", select_object[0].text)

    ticker  = select_object[0].span.string
    price_change = select_object[0].span.find_next_sibling().string

    print(ticker)
    print(price_change)

    logging.info("extract_links_and_titles() was ended")
    return output_dict


def main():
    """
    Main function:
    """
    logging.info("main() started")

    extract_links_and_titles()

    logging.info("main() completed")


if __name__ == "__main__":
    main()
